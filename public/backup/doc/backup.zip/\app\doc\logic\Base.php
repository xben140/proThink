<?php

	namespace app\doc\logic;

	use app\common\logic\LogicBase;

	class Base extends LogicBase
	{

	}