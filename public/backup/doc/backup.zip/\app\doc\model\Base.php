<?php

	namespace app\doc\model;

	use app\common\model\ModelBase;

	class Base extends ModelBase
	{

	}