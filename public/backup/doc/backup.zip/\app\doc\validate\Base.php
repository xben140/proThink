<?php

	namespace app\doc\validate;

	use app\common\validate\ValidateBase;

	class Base extends ValidateBase
	{

	}