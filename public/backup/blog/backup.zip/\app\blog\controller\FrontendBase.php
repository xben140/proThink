<?php

	namespace app\blog\controller;

	use app\common\controller\CustomFrontendBase;

	/**
	 * 前台基类
	 * Class BlogBase
	 * @package app\portal\controller
	 */
	class FrontendBase extends CustomFrontendBase
	{

	}