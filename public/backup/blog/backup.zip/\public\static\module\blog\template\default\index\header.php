<header class="main-header">
	<div class="container">
		<div class="row">
			<div class="col-sm-8">
				<h3>
					<a href="/">{:$blog_name}</a>
				</h3>
			</div>
		</div>
	</div>
</header>