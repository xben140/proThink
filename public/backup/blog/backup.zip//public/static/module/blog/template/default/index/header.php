<header class="main-header">
	<div class="container">
		<div class="row">
			<div class="col-sm-8">
				<h1>
					<a href="/">{:$blog_name}</a>
				</h1>
			</div>
		</div>
	</div>
</header>