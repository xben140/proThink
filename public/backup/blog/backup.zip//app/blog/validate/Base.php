<?php

	namespace app\blog\validate;

	use app\common\validate\ValidateBase;

	class Base extends ValidateBase
	{

	}