<?php

	namespace app\blog\logic;

	use app\common\logic\LogicBase;

	class Base extends LogicBase
	{

	}