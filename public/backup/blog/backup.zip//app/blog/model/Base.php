<?php

	namespace app\blog\model;

	use app\common\model\ModelBase;

	class Base extends ModelBase
	{

	}