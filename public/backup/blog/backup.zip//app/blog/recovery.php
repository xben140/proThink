<?php
	//此处数据将写入ithink_recovery表
	return [
		[
			'name'   => '博文表' ,
			'field'  => 'title' ,
			'remark' => '博客文章' ,
			//斜线必须写4个
			'tab_db' => 'app\\\\blog\\\\controller\\\\Blogarticle' ,
		] ,
	];