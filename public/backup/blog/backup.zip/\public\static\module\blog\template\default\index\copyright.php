
<div class="copyright">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<span>Copyright &copy; <a href="http://www.ghostchina.com/">Ghost中文网</a></span>
				|
				<span><a href="http://www.miibeian.gov.cn/" target="_blank">京ICP备11008151号</a></span>
				|
				<span>京公网安备11010802014853</span>
			</div>
		</div>
	</div>
</div>
